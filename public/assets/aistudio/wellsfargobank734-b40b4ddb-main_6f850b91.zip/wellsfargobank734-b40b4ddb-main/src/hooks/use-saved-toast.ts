import { useCallback, useRef, useState } from 'react';

export const useSavedToast = () => {
  const [show, setShow] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const ping = useCallback(() => {
    setShow(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setShow(false), 1600);
  }, []);

  return { show, ping };
};
