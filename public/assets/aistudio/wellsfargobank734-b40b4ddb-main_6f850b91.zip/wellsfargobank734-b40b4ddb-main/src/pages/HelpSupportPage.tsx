import { useState } from 'react';
import { PageShell, Section, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import { Phone, MessageSquare, MapPin, AlertTriangle, ChevronDown } from 'lucide-react';

const FAQS = [
  { q: 'How do I reset my password?', a: 'Go to Profile > Security Center > Change Password, enter your current password and choose a new one of at least 8 characters.' },
  { q: 'How long do transfers take?', a: 'Internal transfers are instant. Domestic wires post the same business day when submitted before 2:00 PM local time. International wires take 1-3 business days.' },
  { q: 'How do I freeze a lost card?', a: 'Open Profile > Manage Cards, tap the affected card and switch on "Freeze card". You can unfreeze it at any time.' },
  { q: 'Where can I find my statements?', a: 'Profile > Statements lets you pick an account and download any monthly statement as a CSV file.' },
  { q: 'What are the wire transfer fees?', a: 'Domestic outgoing wires cost $25, international outgoing wires $45, and incoming wires $15.' },
];

const HelpSupportPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const [open, setOpen] = useState<number | null>(null);
  const [form, setForm] = useState({ subject: '', message: '' });
  const { show, ping } = useSavedToast();
  const [sent, setSent] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject || !form.message) return;
    setForm({ subject: '', message: '' });
    setSent(true);
    ping();
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <PageShell title="Help & Support" subtitle="Contact us, FAQ" onBack={() => onNavigate('profile')}>
      <Section title="Contact">
        {[
          { icon: <Phone className="w-5 h-5" />, label: 'Call support', desc: '1-800-869-3557 · 24/7', href: 'tel:18008693557' },
          { icon: <MessageSquare className="w-5 h-5" />, label: 'Chat with us', desc: 'Average wait 2 minutes' },
          { icon: <MapPin className="w-5 h-5" />, label: 'Find a branch', desc: 'Locations near you', href: 'https://maps.google.com/?q=bank+branch' },
          { icon: <AlertTriangle className="w-5 h-5" />, label: 'Report fraud', desc: 'Unauthorized activity', href: 'tel:18008693557' },
        ].map(c =>
          c.href ? (
            <a key={c.label} href={c.href} target="_blank" rel="noreferrer" className="w-full flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">{c.icon}</div>
              <div><p className="text-sm font-semibold text-foreground">{c.label}</p><p className="text-xs text-muted-foreground">{c.desc}</p></div>
            </a>
          ) : (
            <div key={c.label} className="w-full flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">{c.icon}</div>
              <div><p className="text-sm font-semibold text-foreground">{c.label}</p><p className="text-xs text-muted-foreground">{c.desc}</p></div>
            </div>
          ),
        )}
      </Section>

      <Section title="Frequently Asked Questions">
        {FAQS.map((f, i) => (
          <div key={f.q}>
            <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center gap-3 p-4 text-left">
              <p className="flex-1 text-sm font-semibold text-foreground">{f.q}</p>
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${open === i ? 'rotate-180' : ''}`} />
            </button>
            {open === i && <p className="px-4 pb-4 text-xs text-muted-foreground">{f.a}</p>}
          </div>
        ))}
      </Section>

      <Section title="Send us a message">
        <form onSubmit={submit} className="p-4 space-y-3">
          <input
            value={form.subject}
            onChange={e => setForm({ ...form, subject: e.target.value })}
            placeholder="Subject"
            className="w-full bg-transparent text-sm text-foreground border-b border-border focus:border-primary focus:outline-none py-2"
          />
          <textarea
            value={form.message}
            onChange={e => setForm({ ...form, message: e.target.value })}
            placeholder="How can we help?"
            rows={4}
            className="w-full bg-muted rounded-lg p-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          {sent && <p className="text-xs text-primary">Message sent. A specialist will reply within 24 hours.</p>}
          <button type="submit" className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold">Send message</button>
        </form>
      </Section>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default HelpSupportPage;
