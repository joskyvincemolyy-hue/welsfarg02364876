import { useBanking } from '@/contexts/BankingContext';
import profilePhotoAsset from '@/assets/profile-photo.jpg.asset.json';
import { ArrowLeft, ChevronRight, Shield, CreditCard, Bell, Lock, HelpCircle, LogOut, FileText, Globe, Smartphone, History } from 'lucide-react';

const ProfilePage = ({ onNavigate, onLogout }: { onNavigate: (page: string) => void; onLogout: () => void }) => {
  const { userName, accountNumber, routingNumber } = useBanking();

  const menuItems = [
    { icon: <CreditCard className="w-5 h-5" />, label: 'Manage Cards', desc: 'View and manage your cards', page: 'manage-cards' },
    { icon: <Shield className="w-5 h-5" />, label: 'Security Center', desc: 'Password, biometrics, 2FA', page: 'security-center' },
    { icon: <Bell className="w-5 h-5" />, label: 'Notifications', desc: 'Alerts and preferences', page: 'notification-settings' },
    { icon: <FileText className="w-5 h-5" />, label: 'Statements', desc: 'Download account statements', page: 'statements' },
    { icon: <Globe className="w-5 h-5" />, label: 'Wire Transfers', desc: 'International wire settings', page: 'wire-transfers' },
    { icon: <Smartphone className="w-5 h-5" />, label: 'Mobile Settings', desc: 'App preferences', page: 'mobile-settings' },
    { icon: <Lock className="w-5 h-5" />, label: 'Privacy', desc: 'Data sharing & privacy', page: 'privacy' },
    { icon: <History className="w-5 h-5" />, label: 'Transaction History', desc: 'All account activity', page: 'transaction-history' },
    { icon: <HelpCircle className="w-5 h-5" />, label: 'Help & Support', desc: 'Contact us, FAQ', page: 'help-support' },
  ];

  return (
    <div className="min-h-screen bg-background pb-8">
      <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4">
        <button onClick={() => onNavigate('dashboard')} aria-label="Go back"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
        <h1 className="text-xl font-bold text-foreground">Profile</h1>
      </div>

      <div className="px-5 mt-4">
        <button
          onClick={() => onNavigate('account-details')}
          className="w-full bg-card rounded-2xl p-5 flex items-center gap-4 shadow-sm text-left active:scale-[0.98] transition-transform"
        >
          <img src={profilePhotoAsset.url} alt={userName} className="w-16 h-16 rounded-full object-cover border-2 border-primary" />
          <div className="flex-1">
            <h2 className="text-lg font-bold text-foreground">{userName}</h2>
            <p className="text-xs text-muted-foreground">Premium Account Member</p>
            <p className="text-xs text-muted-foreground mt-1">Account: {accountNumber}</p>
            <p className="text-xs text-muted-foreground">Routing: {routingNumber}</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>
      </div>

      <div className="px-5 mt-4 space-y-2">
        {menuItems.map(item => (
          <button
            key={item.label}
            onClick={() => onNavigate(item.page)}
            className="w-full bg-card rounded-xl p-4 flex items-center gap-3 shadow-sm active:scale-[0.98] transition-transform"
          >
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">{item.icon}</div>
            <div className="flex-1 text-left">
              <p className="text-sm font-semibold text-foreground">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
        ))}
      </div>

      <div className="px-5 mt-4">
        <button onClick={onLogout} className="w-full bg-card rounded-xl p-4 flex items-center gap-3 shadow-sm text-destructive active:scale-[0.98] transition-transform">
          <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center"><LogOut className="w-5 h-5" /></div>
          <span className="text-sm font-semibold">Sign Out</span>
        </button>
      </div>
    </div>
  );
};

export default ProfilePage;
