import { useState } from 'react';
import { useBanking } from '@/contexts/BankingContext';
import CircleLoader from '@/components/CircleLoader';
import { ArrowLeft, Check, X } from 'lucide-react';

interface TransferPageProps {
  onNavigate: (page: string) => void;
}

const TransferPage = ({ onNavigate }: TransferPageProps) => {
  const { accounts, addTransaction, debitAccount } = useBanking();
  const [step, setStep] = useState<'form' | 'pin' | 'loading' | 'success'>('form');
  const [fromAccount, setFromAccount] = useState(accounts[0].id);
  const [recipientName, setRecipientName] = useState('');
  const [recipientBank, setRecipientBank] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [transferRef] = useState(`WF${Date.now().toString().slice(-8)}`);

  const selectedAccount = accounts.find(a => a.id === fromAccount)!;

  const handleContinue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName || !amount || !recipientAccount) return;
    if (parseFloat(amount) > selectedAccount.balance) return;
    setStep('pin');
  };

  const handlePinSubmit = () => {
    if (pin === '7339') {
      setPinError('');
      setStep('loading');
      setTimeout(() => {
        const amt = parseFloat(amount);
        debitAccount(fromAccount, amt);
        addTransaction({
          name: recipientName,
          date: `Today, ${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`,
          amount: amt,
          type: 'debit',
          category: 'Transfer',
          icon: 'send',
          accountId: fromAccount,
        });
        setStep('success');
      }, 2500);
    } else {
      setPinError('Invalid PIN. Please try again.');
      setPin('');
    }
  };

  if (step === 'loading') return <CircleLoader message="Processing transfer..." />;

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-card flex flex-col items-center justify-center px-6">
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-6 animate-fade-up">
          <Check className="w-10 h-10 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2 animate-fade-up">Transfer Successful!</h2>
        <p className="text-muted-foreground text-sm text-center mb-8 animate-fade-up">Your money has been sent successfully</p>

        <div className="w-full bg-muted rounded-2xl p-5 space-y-3 animate-fade-up" style={{ animationDelay: '0.2s' }}>
          <InfoRow label="Reference" value={transferRef} />
          <InfoRow label="To" value={recipientName} />
          <InfoRow label="Bank" value={recipientBank || 'External Bank'} />
          <InfoRow label="Account" value={recipientAccount} />
          <InfoRow label="Amount" value={`$${parseFloat(amount).toFixed(2)}`} highlight />
          <InfoRow label="From" value={`${selectedAccount.name} (****${selectedAccount.lastFour})`} />
          <InfoRow label="Date" value={new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} />
          <InfoRow label="Status" value="Completed" status />
          {note && <InfoRow label="Note" value={note} />}
        </div>

        <button onClick={() => onNavigate('dashboard')} className="w-full mt-6 py-3 bg-primary text-primary-foreground font-semibold rounded-lg">
          Back to Home
        </button>
      </div>
    );
  }

  if (step === 'pin') {
    return (
      <div className="min-h-screen bg-card flex flex-col items-center justify-center px-6">
        <button onClick={() => setStep('form')} aria-label="Go back" className="absolute top-6 left-4"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Enter Transfer PIN</h2>
        <p className="text-sm text-muted-foreground mb-6">Confirm transfer of <span className="font-bold text-foreground">${parseFloat(amount).toFixed(2)}</span> to {recipientName}</p>
        <input
          type="password"
          maxLength={4}
          value={pin}
          onChange={e => setPin(e.target.value.replace(/\D/g, ''))}
          placeholder="****"
          className="w-40 text-center text-3xl tracking-[0.5em] py-3 border-2 border-border rounded-lg bg-card text-foreground focus:border-primary focus:outline-none"
        />
        {pinError && <p className="text-destructive text-sm mt-3">{pinError}</p>}
        <button onClick={handlePinSubmit} disabled={pin.length !== 4} className="w-full max-w-xs mt-6 py-3 bg-primary text-primary-foreground font-semibold rounded-lg disabled:opacity-50">
          Confirm Transfer
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4">
        <button onClick={() => onNavigate('dashboard')} aria-label="Go back to dashboard"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
        <h1 className="text-xl font-bold text-foreground">Transfer Money</h1>
      </div>

      <form onSubmit={handleContinue} className="px-5 mt-4 space-y-4">
        <div className="bg-card rounded-xl p-4 shadow-sm">
          <label className="text-xs text-muted-foreground font-medium">From Account</label>
          <select value={fromAccount} onChange={e => setFromAccount(e.target.value)} className="w-full mt-1 py-2 bg-transparent text-foreground font-semibold focus:outline-none">
            {accounts.filter(a => a.type !== 'credit').map(a => (
              <option key={a.id} value={a.id}>{a.name} - ${a.balance.toFixed(2)}</option>
            ))}
          </select>
        </div>

        <div className="bg-card rounded-xl p-4 shadow-sm space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Recipient Details</h3>
          <input type="text" placeholder="Recipient Name" value={recipientName} onChange={e => setRecipientName(e.target.value)} className="w-full py-2 border-b border-border bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" required />
          <input type="text" placeholder="Bank Name" value={recipientBank} onChange={e => setRecipientBank(e.target.value)} className="w-full py-2 border-b border-border bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" />
          <input type="text" placeholder="Account Number" value={recipientAccount} onChange={e => setRecipientAccount(e.target.value)} className="w-full py-2 border-b border-border bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary" required />
        </div>

        <div className="bg-card rounded-xl p-4 shadow-sm">
          <label className="text-xs text-muted-foreground font-medium">Amount (USD)</label>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-bold text-foreground">$</span>
            <input type="number" step="0.01" min="0.01" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} className="flex-1 text-2xl font-bold bg-transparent text-foreground focus:outline-none" required />
          </div>
          {parseFloat(amount) > selectedAccount.balance && <p className="text-destructive text-xs mt-1">Insufficient balance</p>}
        </div>

        <div className="bg-card rounded-xl p-4 shadow-sm">
          <input type="text" placeholder="Add a note (optional)" value={note} onChange={e => setNote(e.target.value)} className="w-full bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none" />
        </div>

        <button type="submit" disabled={!recipientName || !amount || !recipientAccount || parseFloat(amount) > selectedAccount.balance} className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg disabled:opacity-50">
          Continue
        </button>
      </form>
    </div>
  );
};

const InfoRow = ({ label, value, highlight, status }: { label: string; value: string; highlight?: boolean; status?: boolean }) => (
  <div className="flex justify-between items-center">
    <span className="text-xs text-muted-foreground">{label}</span>
    <span className={`text-sm font-semibold ${highlight ? 'text-primary text-lg' : status ? 'text-green-600' : 'text-foreground'}`}>{value}</span>
  </div>
);

export default TransferPage;
