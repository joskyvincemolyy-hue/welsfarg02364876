import { useBanking } from '@/contexts/BankingContext';
import { ArrowLeft } from 'lucide-react';

const AnalyticsPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { accounts, transactions } = useBanking();

  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);
  const totalSpent = transactions.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);
  const totalReceived = transactions.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);

  const categories = [
    { name: 'Transport', amount: 28.51, pct: 14, color: 'bg-primary' },
    { name: 'Transfer', amount: 100.00, pct: 50, color: 'bg-secondary' },
    { name: 'Food', amount: 6.99, pct: 3, color: 'bg-wf-dark' },
    { name: 'Entertainment', amount: 15.99, pct: 8, color: 'bg-muted-foreground' },
    { name: 'Other', amount: 50.00, pct: 25, color: 'bg-destructive' },
  ];

  return (
    <div className="min-h-screen bg-background pb-8">
      <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4">
        <button onClick={() => onNavigate('dashboard')} aria-label="Go back to dashboard"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
        <h1 className="text-xl font-bold text-foreground">Analytics</h1>
      </div>

      <div className="px-5 mt-4 grid grid-cols-2 gap-3">
        <div className="bg-card rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Total Balance</p>
          <p className="text-lg font-bold text-foreground">${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Total Spent</p>
          <p className="text-lg font-bold text-destructive">${totalSpent.toFixed(2)}</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-sm col-span-2">
          <p className="text-xs text-muted-foreground">Total Received</p>
          <p className="text-lg font-bold text-green-600">${totalReceived.toFixed(2)}</p>
        </div>
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-lg font-bold text-foreground mb-3">Spending by Category</h2>
        <div className="space-y-3">
          {categories.map(c => (
            <div key={c.name}>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-foreground font-medium">{c.name}</span>
                <span className="text-muted-foreground">${c.amount.toFixed(2)}</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${c.color}`} style={{ width: `${c.pct}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
