import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, SelectRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';

const MobileSettingsPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { settings, updateSetting } = useBanking();
  const { show, ping } = useSavedToast();
  const set = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) => {
    updateSetting(k, v);
    ping();
  };

  return (
    <PageShell title="Mobile Settings" subtitle="App preferences" onBack={() => onNavigate('profile')}>
      <Section title="Appearance">
        <ToggleRow label="Dark mode" desc="Use the dark theme" checked={settings.darkMode} onChange={v => set('darkMode', v)} />
        <SelectRow label="Language" value={settings.language} options={['English', 'Español', 'Français', 'Deutsch', '中文']} onChange={v => set('language', v)} />
      </Section>

      <Section title="Home Screen">
        <ToggleRow label="Hide balances" desc="Mask amounts until tapped" checked={settings.hideBalances} onChange={v => set('hideBalances', v)} />
        <ToggleRow label="Quick balance" desc="See balances before signing in" checked={settings.quickBalance} onChange={v => set('quickBalance', v)} />
      </Section>

      <Section title="About">
        <div className="p-4 flex justify-between"><p className="text-sm text-foreground">App version</p><p className="text-sm font-semibold text-foreground">4.12.0</p></div>
        <div className="p-4 flex justify-between"><p className="text-sm text-foreground">Build</p><p className="text-sm font-semibold text-foreground">2026.08.13</p></div>
      </Section>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default MobileSettingsPage;
