import { useEffect, useState } from 'react';
import logo from '@/assets/wells-fargo-logo.png';

const SplashScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 8000;
    const interval = 50;
    const step = (interval / duration) * 100;
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) { clearInterval(timer); onComplete(); return 100; }
        return prev + step;
      });
    }, interval);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 wf-gradient flex flex-col items-center justify-center">
      <h1 className="sr-only">Wells Fargo Mobile Banking</h1>
      <div className="animate-fade-up">
        <img src={logo} alt="Wells Fargo" className="w-48 h-48 object-contain mb-8" />
      </div>
      <div className="w-24 h-1 bg-primary-foreground/20 rounded-full overflow-hidden mt-4">
        <div className="h-full bg-secondary rounded-full transition-all duration-100" style={{ width: `${progress}%` }} />
      </div>
    </div>
  );
};

export default SplashScreen;
