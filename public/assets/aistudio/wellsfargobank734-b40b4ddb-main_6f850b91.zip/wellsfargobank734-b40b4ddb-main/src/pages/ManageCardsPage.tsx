import { useState } from 'react';
import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, InputRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import { Snowflake, CreditCard } from 'lucide-react';
import visaLogo from '@/assets/visa-logo.svg';

const ManageCardsPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { cards, updateCard, userName } = useBanking();
  const [openId, setOpenId] = useState(cards[0]?.id ?? '');
  const { show, ping } = useSavedToast();

  const change = (id: string, patch: Parameters<typeof updateCard>[1]) => {
    updateCard(id, patch);
    ping();
  };

  return (
    <PageShell title="Manage Cards" subtitle="View and manage your cards" onBack={() => onNavigate('profile')}>
      {cards.map(card => (
        <div key={card.id} className="space-y-3">
          <button onClick={() => setOpenId(openId === card.id ? '' : card.id)} className="w-full text-left">
            <div className={`card-gradient rounded-2xl p-5 relative overflow-hidden ${card.frozen ? 'opacity-60' : ''}`}>
              <div className="flex items-center justify-between mb-6">
                <p className="text-primary-foreground/80 text-sm font-medium">{card.name}</p>
                {card.brand === 'Visa' ? (
                  <img src={visaLogo} alt="Visa" className="h-5 brightness-0 invert" />
                ) : (
                  <CreditCard className="w-5 h-5 text-primary-foreground" />
                )}
              </div>
              <p className="text-primary-foreground text-lg tracking-[0.25em] font-mono mb-3">**** **** **** {card.lastFour}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-primary-foreground/60 text-[10px]">CARD HOLDER</p>
                  <p className="text-primary-foreground text-sm font-medium">{userName.toUpperCase()}</p>
                </div>
                <div className="text-right">
                  <p className="text-primary-foreground/60 text-[10px]">EXPIRES</p>
                  <p className="text-primary-foreground text-sm font-medium">{card.expires}</p>
                </div>
              </div>
              {card.frozen && (
                <div className="absolute top-3 right-3 flex items-center gap-1 bg-card/90 rounded-full px-2 py-1">
                  <Snowflake className="w-3 h-3 text-primary" />
                  <span className="text-[10px] font-bold text-primary">FROZEN</span>
                </div>
              )}
            </div>
          </button>

          {openId === card.id && (
            <Section>
              <ToggleRow label="Freeze card" desc="Temporarily block all transactions" checked={card.frozen} onChange={v => change(card.id, { frozen: v })} />
              <ToggleRow label="Contactless payments" desc="Tap to pay" checked={card.contactless} onChange={v => change(card.id, { contactless: v })} />
              <ToggleRow label="Online payments" desc="E-commerce and in-app purchases" checked={card.onlinePayments} onChange={v => change(card.id, { onlinePayments: v })} />
              <ToggleRow label="International use" desc="Allow transactions abroad" checked={card.internationalUse} onChange={v => change(card.id, { internationalUse: v })} />
              <InputRow
                label="Daily spend limit"
                prefix="$"
                type="number"
                value={card.spendLimit}
                onChange={v => change(card.id, { spendLimit: Number(v) || 0 })}
              />
            </Section>
          )}
        </div>
      ))}
      <SavedToast show={show} />
    </PageShell>
  );
};

export default ManageCardsPage;
