import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, SelectRow, InputRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import { Globe } from 'lucide-react';

const WireTransfersPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { settings, updateSetting } = useBanking();
  const { show, ping } = useSavedToast();
  const set = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) => {
    updateSetting(k, v);
    ping();
  };

  return (
    <PageShell title="Wire Transfers" subtitle="International wire settings" onBack={() => onNavigate('profile')}>
      <div className="bg-card rounded-2xl p-5 shadow-sm flex items-center gap-3">
        <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
          <Globe className="w-6 h-6 text-primary" />
        </div>
        <div>
          <p className="text-sm font-bold text-foreground">
            International wires {settings.internationalWires ? 'enabled' : 'disabled'}
          </p>
          <p className="text-xs text-muted-foreground">
            Daily limit ${settings.wireDailyLimit.toLocaleString()} · {settings.wireCurrency}
          </p>
        </div>
      </div>

      <Section title="Preferences">
        <ToggleRow
          label="Allow international wires"
          desc="Send funds outside the United States"
          checked={settings.internationalWires}
          onChange={v => set('internationalWires', v)}
        />
        <SelectRow label="Default currency" value={settings.wireCurrency} options={['USD', 'EUR', 'GBP', 'CAD', 'NGN', 'JPY', 'AUD']} onChange={v => set('wireCurrency', v)} />
        <InputRow label="Daily wire limit" prefix="$" type="number" value={settings.wireDailyLimit} onChange={v => set('wireDailyLimit', Number(v) || 0)} />
        <InputRow label="SWIFT / BIC code" value={settings.swiftCode} onChange={v => set('swiftCode', v.toUpperCase())} />
      </Section>

      <Section title="Fees">
        {[
          { label: 'Domestic wire (outgoing)', value: '$25.00' },
          { label: 'International wire (outgoing)', value: '$45.00' },
          { label: 'Incoming wire', value: '$15.00' },
        ].map(f => (
          <div key={f.label} className="p-4 flex justify-between">
            <p className="text-sm text-foreground">{f.label}</p>
            <p className="text-sm font-semibold text-foreground">{f.value}</p>
          </div>
        ))}
      </Section>

      <button onClick={() => onNavigate('transfer')} className="w-full bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold">
        Start a wire transfer
      </button>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default WireTransfersPage;
