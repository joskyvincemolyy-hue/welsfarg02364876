import { useState } from 'react';
import logo from '@/assets/wells-fargo-logo.png';

const LoginPage = ({ onLogin }: { onLogin: () => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'Jackson Browne' && password === 'hwrr5733') {
      setError('');
      onLogin();
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div className="min-h-screen bg-card flex flex-col">
      <div className="flex items-center justify-between px-6 pt-6">
        <img src={logo} alt="Wells Fargo" className="w-16 h-16 object-contain" />
        <button className="text-primary" aria-label="Open account menu">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        </button>
      </div>

      <div className="px-6 pt-8 pb-4">
        <h1 className="sr-only">Secure Online Banking Login</h1>
        <p className="text-3xl font-bold text-foreground">Good Afternoon</p>
      </div>

      <form onSubmit={handleSubmit} className="px-6 flex-1 flex flex-col gap-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={e => setUsername(e.target.value)}
            className="w-full px-4 py-3 border-b-2 border-primary bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none text-base"
          />
        </div>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="w-full px-4 py-3 border-b-2 border-primary bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none text-base pr-12"
          />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-3 text-muted-foreground text-sm">
            {showPassword ? 'Hide' : 'Show'}
          </button>
        </div>

        {error && <p className="text-destructive text-sm">{error}</p>}

        <label className="flex items-center gap-2 text-sm text-foreground">
          <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} className="w-4 h-4 accent-secondary rounded" />
          Remember Me
        </label>

        <button type="submit" className="w-full py-3 bg-secondary text-secondary-foreground font-semibold rounded-md text-lg hover:opacity-90 transition-opacity">
          Sign In
        </button>

        <p className="text-sm text-primary font-semibold text-center cursor-pointer">Forgot username or password?</p>

        <div className="flex gap-3 mt-4">
          <button type="button" className="flex-1 bg-primary text-primary-foreground rounded-lg py-4 px-3 flex items-center gap-2 text-sm font-semibold">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M6 12h12"/></svg>
            Explore Our Products
          </button>
          <button type="button" className="flex-1 bg-primary text-primary-foreground rounded-lg py-4 px-3 flex items-center gap-2 text-sm font-semibold">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
            Earn More Points
          </button>
        </div>
      </form>

      <div className="bg-muted p-4 mt-6">
        <p className="text-sm font-semibold text-primary mb-2">Other Services</p>
        <div className="grid grid-cols-2 gap-1 text-xs text-muted-foreground">
          <span>Corporations & Institutions</span><span>Insights & Economics</span>
          <span>Institutional Investing</span><span>Forgot password?</span>
          <span>Commercial Real Estate</span><span>Security Center</span>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
