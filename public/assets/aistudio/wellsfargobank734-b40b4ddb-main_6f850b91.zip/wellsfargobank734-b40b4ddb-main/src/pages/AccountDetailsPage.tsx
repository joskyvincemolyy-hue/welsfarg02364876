import { useState } from 'react';
import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, InputRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import profilePhotoAsset from '@/assets/profile-photo.jpg.asset.json';
import { BadgeCheck, Copy, Pencil, Check } from 'lucide-react';

const AccountDetailsPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { profile, updateProfile, accounts, accountNumber, routingNumber, transactions } = useBanking();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(profile);
  const [copied, setCopied] = useState('');
  const { show, ping } = useSavedToast();

  const totalBalance = accounts.reduce((s, a) => s + (a.type === 'credit' ? 0 : a.balance), 0);

  const copy = (label: string, value: string) => {
    navigator.clipboard?.writeText(value);
    setCopied(label);
    setTimeout(() => setCopied(''), 1500);
  };

  const save = () => {
    updateProfile(draft);
    setEditing(false);
    ping();
  };

  return (
    <PageShell title="Account Details" subtitle="Personal & banking information" onBack={() => onNavigate('profile')}>
      <div className="bg-card rounded-2xl p-5 shadow-sm flex items-center gap-4">
        <img src={profilePhotoAsset.url} alt={profile.userName} className="w-20 h-20 rounded-full object-cover border-2 border-primary" />
        <div className="flex-1">
          <div className="flex items-center gap-1">
            <h2 className="text-lg font-bold text-foreground">{profile.userName}</h2>
            <BadgeCheck className="w-4 h-4 text-primary" />
          </div>
          <p className="text-xs text-muted-foreground">Premium Account Member since 2014</p>
          <p className="text-xs text-muted-foreground mt-1">{profile.occupation}</p>
        </div>
      </div>

      <div className="bg-card rounded-2xl p-5 shadow-sm">
        <p className="text-xs text-muted-foreground">Total deposit balance</p>
        <p className="text-2xl font-bold text-foreground">
          ${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </p>
        <p className="text-xs text-muted-foreground mt-1">{transactions.length.toLocaleString()} transactions on record</p>
      </div>

      <Section title="Banking Information">
        {[
          { label: 'Account number', value: accountNumber },
          { label: 'Routing number', value: routingNumber },
          { label: 'SWIFT / BIC', value: 'WFBIUS6S' },
          { label: 'Branch', value: 'San Francisco Main, CA' },
        ].map(row => (
          <button key={row.label} onClick={() => copy(row.label, row.value)} className="w-full flex items-center gap-3 p-4 text-left">
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">{row.label}</p>
              <p className="text-sm font-semibold text-foreground">{row.value}</p>
            </div>
            {copied === row.label ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4 text-muted-foreground" />}
          </button>
        ))}
      </Section>

      <Section title="Your Accounts">
        {accounts.map(a => (
          <button key={a.id} onClick={() => onNavigate(`card-details:${a.id}`)} className="w-full flex items-center gap-3 p-4 text-left">
            <span className="w-12 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">{a.lastFour}</span>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">{a.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{a.type}</p>
            </div>
            <p className="text-sm font-bold text-foreground">${a.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
          </button>
        ))}
      </Section>

      <div className="flex items-center justify-between">
        <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Personal Details</h2>
        <button
          onClick={() => (editing ? save() : (setDraft(profile), setEditing(true)))}
          className="text-xs font-semibold text-primary flex items-center gap-1"
        >
          {editing ? <><Check className="w-3.5 h-3.5" /> Save</> : <><Pencil className="w-3.5 h-3.5" /> Edit</>}
        </button>
      </div>

      <Section>
        {editing ? (
          <>
            <InputRow label="Full name" value={draft.userName} onChange={v => setDraft({ ...draft, userName: v })} />
            <InputRow label="Email" value={draft.email} onChange={v => setDraft({ ...draft, email: v })} />
            <InputRow label="Phone" value={draft.phone} onChange={v => setDraft({ ...draft, phone: v })} />
            <InputRow label="Address" value={draft.address} onChange={v => setDraft({ ...draft, address: v })} />
            <InputRow label="Date of birth" value={draft.dateOfBirth} onChange={v => setDraft({ ...draft, dateOfBirth: v })} />
            <InputRow label="Occupation" value={draft.occupation} onChange={v => setDraft({ ...draft, occupation: v })} />
          </>
        ) : (
          [
            { label: 'Full name', value: profile.userName },
            { label: 'Email', value: profile.email },
            { label: 'Phone', value: profile.phone },
            { label: 'Address', value: profile.address },
            { label: 'Date of birth', value: profile.dateOfBirth },
            { label: 'Occupation', value: profile.occupation },
          ].map(r => (
            <div key={r.label} className="p-4">
              <p className="text-xs text-muted-foreground">{r.label}</p>
              <p className="text-sm font-semibold text-foreground">{r.value}</p>
            </div>
          ))
        )}
      </Section>

      <button onClick={() => onNavigate('transaction-history')} className="w-full bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold">
        View full transaction history
      </button>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default AccountDetailsPage;
