import { useBanking } from '@/contexts/BankingContext';
import { Home, BarChart3, HeadphonesIcon, User, Bell } from 'lucide-react';
import chipImg from '@/assets/chip.png';
import visaLogo from '@/assets/visa-logo.svg';

const Dashboard = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { accounts, transactions, userName, settings } = useBanking();
  const checking = accounts[0];
  const savings = accounts[1];
  const credit = accounts[2];
  const money = (n: number) =>
    settings.hideBalances ? '••••••' : `$${n.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;

  const today = new Date();
  const dateStr = today.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  const expenseCategories = [
    { name: 'Transfers', color: 'hsl(var(--primary))', pct: 45 },
    { name: 'Cash withdrawal', color: 'hsl(var(--secondary))', pct: 30 },
    { name: 'Other', color: 'hsl(var(--wf-dark))', pct: 25 },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card px-5 pt-6 pb-4">
        <p className="text-xs text-muted-foreground">{dateStr}</p>
        <div className="flex items-center justify-between mt-1">
          <h1 className="text-2xl font-bold text-foreground">Hello, {userName.split(' ')[0]}</h1>
          <button onClick={() => onNavigate('notifications')} aria-label="View notifications" className="relative">
            <Bell className="w-6 h-6 text-primary" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full" />
          </button>
        </div>
      </div>

      {/* Credit Card Preview */}
      <div className="px-5 mt-4">
        <div className="card-gradient rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between mb-6">
            <p className="text-primary-foreground/80 text-sm font-medium">Visa Signature</p>
            <img src={visaLogo} alt="Visa" className="h-6 brightness-0 invert" />
          </div>
          <img src={chipImg} alt="Chip" className="w-10 h-8 object-contain mb-4" />
          <p className="text-primary-foreground text-lg tracking-[0.25em] font-mono mb-1">**** **** **** {credit.lastFour}</p>
          <div className="flex items-center justify-between mt-3">
            <div>
              <p className="text-primary-foreground/60 text-[10px]">CARD HOLDER</p>
              <p className="text-primary-foreground text-sm font-medium">{userName.toUpperCase()}</p>
            </div>
            <div className="text-right">
              <p className="text-primary-foreground/60 text-[10px]">EXPIRES</p>
              <p className="text-primary-foreground text-sm font-medium">09/28</p>
            </div>
          </div>
        </div>
      </div>

      {/* Accounts */}
      <div className="px-5 mt-4 space-y-3">
        {[checking, savings, credit].map(acc => (
          <button key={acc.id} onClick={() => onNavigate(`card-details:${acc.id}`)} className="w-full bg-card rounded-xl p-4 flex items-center gap-4 shadow-sm active:scale-[0.98] transition-transform">
            <span className="w-12 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">{acc.lastFour}</span>
            <div className="flex-1 text-left">
              <p className="text-sm font-semibold text-foreground">{acc.name}</p>
              <p className="text-xs text-muted-foreground">{acc.type === 'credit' ? 'Outstanding balance' : 'Available balance'}</p>
            </div>
            <p className="text-lg font-bold text-foreground">{money(acc.balance)}</p>
          </button>
        ))}
      </div>

      {/* Expenses Donut */}
      <div className="px-5 mt-6">
        <h2 className="text-lg font-bold text-foreground mb-1">Current Expenses</h2>
        <p className="text-xs text-muted-foreground mb-4">{today.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
        <div className="flex items-center gap-6">
          <div className="flex flex-col gap-2">
            {expenseCategories.map(c => (
              <div key={c.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                <span className="text-xs text-foreground">{c.name}</span>
              </div>
            ))}
          </div>
          <div className="relative w-28 h-28">
            <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
              <circle cx="18" cy="18" r="14" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
              <circle cx="18" cy="18" r="14" fill="none" stroke="hsl(var(--primary))" strokeWidth="4" strokeDasharray="39.6 88" strokeLinecap="round" />
              <circle cx="18" cy="18" r="14" fill="none" stroke="hsl(var(--secondary))" strokeWidth="4" strokeDasharray="26.4 88" strokeDashoffset="-39.6" strokeLinecap="round" />
              <circle cx="18" cy="18" r="14" fill="none" stroke="hsl(var(--wf-dark))" strokeWidth="4" strokeDasharray="22 88" strokeDashoffset="-66" strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-sm font-bold text-foreground">${credit.balance.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Latest Activity */}
      <div className="px-5 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-foreground">Transaction History</h2>
          <button onClick={() => onNavigate('transaction-history')} className="text-xs font-semibold text-primary">See all</button>
        </div>
        <div className="space-y-3">
          {transactions.slice(0, 8).map(tx => (
            <div key={tx.id} className="bg-card rounded-xl p-4 flex items-center gap-3 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground">
                {tx.name.charAt(0)}
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{tx.name}</p>
                <p className="text-xs text-muted-foreground">{tx.date}</p>
              </div>
              <p className={`text-sm font-bold ${tx.type === 'debit' ? 'text-foreground' : 'text-green-600'}`}>
                {tx.type === 'debit' ? '-' : '+'}${tx.amount.toFixed(2)}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around items-center py-2 z-40 max-w-lg mx-auto">
        <NavBtn icon={<Home className="w-5 h-5" />} label="Home" active onClick={() => onNavigate('dashboard')} />
        <NavBtn icon={<BarChart3 className="w-5 h-5" />} label="Analytics" onClick={() => onNavigate('analytics')} />
        <button onClick={() => onNavigate('transfer')} aria-label="Transfer money" className="w-14 h-14 -mt-6 bg-primary rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary-foreground))" strokeWidth="2"><path d="M12 5v14M5 12l7-7 7 7"/></svg>
        </button>
        <NavBtn icon={<HeadphonesIcon className="w-5 h-5" />} label="Support" onClick={() => onNavigate('support')} />
        <NavBtn icon={<User className="w-5 h-5" />} label="Profile" onClick={() => onNavigate('profile')} />
      </nav>
    </div>
  );
};

const NavBtn = ({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-0.5 ${active ? 'text-primary' : 'text-muted-foreground'}`}>
    {icon}
    <span className="text-[10px] font-medium">{label}</span>
  </button>
);

export default Dashboard;
