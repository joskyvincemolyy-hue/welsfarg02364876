import { useState } from 'react';
import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import { ShieldCheck, Smartphone, Monitor } from 'lucide-react';

const SecurityCenterPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { settings, updateSetting } = useBanking();
  const { show, ping } = useSavedToast();
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [msg, setMsg] = useState('');

  const set = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) => {
    updateSetting(k, v);
    ping();
  };

  const changePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.current !== 'hwrr5733') return setMsg('Current password is incorrect.');
    if (pw.next.length < 8) return setMsg('New password must be at least 8 characters.');
    if (pw.next !== pw.confirm) return setMsg('Passwords do not match.');
    setMsg('Password updated successfully.');
    setPw({ current: '', next: '', confirm: '' });
    ping();
  };

  return (
    <PageShell title="Security Center" subtitle="Password, biometrics, 2FA" onBack={() => onNavigate('profile')}>
      <div className="bg-card rounded-2xl p-5 shadow-sm flex items-center gap-3">
        <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
          <ShieldCheck className="w-6 h-6 text-primary" />
        </div>
        <div>
          <p className="text-sm font-bold text-foreground">Your account is protected</p>
          <p className="text-xs text-muted-foreground">
            {[settings.biometrics && 'Biometrics', settings.twoFactor && '2FA', settings.loginAlerts && 'Login alerts'].filter(Boolean).join(' · ') || 'No protections enabled'}
          </p>
        </div>
      </div>

      <Section title="Protection">
        <ToggleRow label="Biometric sign-in" desc="Face ID / fingerprint" checked={settings.biometrics} onChange={v => set('biometrics', v)} />
        <ToggleRow label="Two-factor authentication" desc="One-time code at every sign-in" checked={settings.twoFactor} onChange={v => set('twoFactor', v)} />
        <ToggleRow label="Login alerts" desc="Notify me of new device sign-ins" checked={settings.loginAlerts} onChange={v => set('loginAlerts', v)} />
      </Section>

      <Section title="Change Password">
        <form onSubmit={changePassword} className="p-4 space-y-3">
          {[
            { key: 'current' as const, label: 'Current password' },
            { key: 'next' as const, label: 'New password' },
            { key: 'confirm' as const, label: 'Confirm new password' },
          ].map(f => (
            <div key={f.key}>
              <label className="block text-xs text-muted-foreground mb-1">{f.label}</label>
              <input
                type="password"
                value={pw[f.key]}
                onChange={e => setPw({ ...pw, [f.key]: e.target.value })}
                className="w-full bg-transparent text-sm text-foreground border-b border-border focus:border-primary focus:outline-none py-1"
              />
            </div>
          ))}
          {msg && <p className={`text-xs ${msg.includes('success') ? 'text-primary' : 'text-destructive'}`}>{msg}</p>}
          <button type="submit" className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold">
            Update password
          </button>
        </form>
      </Section>

      <Section title="Active Sessions">
        {[
          { icon: <Smartphone className="w-4 h-4" />, name: 'iPhone 15 Pro · San Francisco, CA', time: 'Active now' },
          { icon: <Monitor className="w-4 h-4" />, name: 'MacBook Pro · San Francisco, CA', time: '2 days ago' },
        ].map(s => (
          <div key={s.name} className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-muted-foreground">{s.icon}</div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">{s.name}</p>
              <p className="text-xs text-muted-foreground">{s.time}</p>
            </div>
          </div>
        ))}
      </Section>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default SecurityCenterPage;
