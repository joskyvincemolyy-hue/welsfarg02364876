import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, InputRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';

const NotificationSettingsPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { settings, updateSetting } = useBanking();
  const { show, ping } = useSavedToast();
  const set = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) => {
    updateSetting(k, v);
    ping();
  };

  return (
    <PageShell title="Notifications" subtitle="Alerts and preferences" onBack={() => onNavigate('profile')}>
      <Section title="Channels">
        <ToggleRow label="Push notifications" desc="On this device" checked={settings.pushNotifications} onChange={v => set('pushNotifications', v)} />
        <ToggleRow label="Email alerts" desc="Statements and security notices" checked={settings.emailAlerts} onChange={v => set('emailAlerts', v)} />
        <ToggleRow label="SMS alerts" desc="Text messages for key events" checked={settings.smsAlerts} onChange={v => set('smsAlerts', v)} />
        <ToggleRow label="Marketing emails" desc="Offers and product news" checked={settings.marketingEmails} onChange={v => set('marketingEmails', v)} />
      </Section>

      <Section title="Balance Alerts">
        <ToggleRow label="Low balance alerts" desc="Warn me before I overdraft" checked={settings.lowBalanceAlerts} onChange={v => set('lowBalanceAlerts', v)} />
        {settings.lowBalanceAlerts && (
          <InputRow
            label="Alert threshold"
            prefix="$"
            type="number"
            value={settings.lowBalanceThreshold}
            onChange={v => set('lowBalanceThreshold', Number(v) || 0)}
          />
        )}
      </Section>

      <button onClick={() => onNavigate('notifications')} className="w-full bg-card rounded-xl p-4 text-sm font-semibold text-primary shadow-sm">
        View notification inbox
      </button>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default NotificationSettingsPage;
