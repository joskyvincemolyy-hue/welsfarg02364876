import { useBanking } from '@/contexts/BankingContext';
import { PageShell, Section, ToggleRow, SavedToast } from '@/components/settings/SettingsUI';
import { useSavedToast } from '@/hooks/use-saved-toast';
import { Lock } from 'lucide-react';

const PrivacyPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { settings, updateSetting, profile, transactions } = useBanking();
  const { show, ping } = useSavedToast();
  const set = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) => {
    updateSetting(k, v);
    ping();
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify({ profile, settings, transactions }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'my-data-export.json';
    a.click();
    URL.revokeObjectURL(url);
    ping();
  };

  return (
    <PageShell title="Privacy" subtitle="Data sharing & privacy" onBack={() => onNavigate('profile')}>
      <div className="bg-card rounded-2xl p-5 shadow-sm flex items-center gap-3">
        <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
          <Lock className="w-6 h-6 text-primary" />
        </div>
        <div>
          <p className="text-sm font-bold text-foreground">You control your data</p>
          <p className="text-xs text-muted-foreground">Choices apply to this account only</p>
        </div>
      </div>

      <Section title="Data Sharing">
        <ToggleRow label="Share data with partners" desc="Third-party marketing partners" checked={settings.shareDataPartners} onChange={v => set('shareDataPartners', v)} />
        <ToggleRow label="Personalized offers" desc="Use my activity to tailor offers" checked={settings.personalizedOffers} onChange={v => set('personalizedOffers', v)} />
        <ToggleRow label="Location tracking" desc="Used for fraud detection & branch finder" checked={settings.locationTracking} onChange={v => set('locationTracking', v)} />
        <ToggleRow label="Usage analytics" desc="Help improve the app" checked={settings.analyticsOptIn} onChange={v => set('analyticsOptIn', v)} />
      </Section>

      <Section title="Your Data">
        <button onClick={exportData} className="w-full p-4 text-left text-sm font-semibold text-primary">Download my data</button>
        <div className="p-4">
          <p className="text-xs text-muted-foreground">
            We never sell your personal banking information. Sharing preferences take effect immediately and are stored on this device.
          </p>
        </div>
      </Section>

      <SavedToast show={show} />
    </PageShell>
  );
};

export default PrivacyPage;
