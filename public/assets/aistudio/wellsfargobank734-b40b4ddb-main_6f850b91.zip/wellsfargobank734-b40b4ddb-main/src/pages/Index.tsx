import { useState, useCallback } from 'react';
import { BankingProvider } from '@/contexts/BankingContext';
import CircleLoader from '@/components/CircleLoader';
import SplashScreen from '@/pages/SplashScreen';
import LoginPage from '@/pages/LoginPage';
import OTPVerification from '@/pages/OTPVerification';
import Dashboard from '@/pages/Dashboard';
import TransferPage from '@/pages/TransferPage';
import ProfilePage from '@/pages/ProfilePage';
import CardDetailsPage from '@/pages/CardDetailsPage';
import AnalyticsPage from '@/pages/AnalyticsPage';
import AccountDetailsPage from '@/pages/AccountDetailsPage';
import ManageCardsPage from '@/pages/ManageCardsPage';
import SecurityCenterPage from '@/pages/SecurityCenterPage';
import NotificationSettingsPage from '@/pages/NotificationSettingsPage';
import StatementsPage from '@/pages/StatementsPage';
import WireTransfersPage from '@/pages/WireTransfersPage';
import MobileSettingsPage from '@/pages/MobileSettingsPage';
import PrivacyPage from '@/pages/PrivacyPage';
import HelpSupportPage from '@/pages/HelpSupportPage';
import TransactionHistoryPage from '@/pages/TransactionHistoryPage';

type AppScreen =
  | 'splash' | 'login' | 'login-loading' | 'otp' | 'otp-loading' | 'dashboard' | 'transfer' | 'profile'
  | 'card-details' | 'analytics' | 'support' | 'notifications' | 'settings'
  | 'account-details' | 'manage-cards' | 'security-center' | 'notification-settings' | 'statements'
  | 'wire-transfers' | 'mobile-settings' | 'privacy' | 'help-support' | 'transaction-history';


const Index = () => {
  const [screen, setScreen] = useState<AppScreen>('splash');
  const [selectedAccountId, setSelectedAccountId] = useState('3');

  const transitionTo = useCallback((target: AppScreen, loadingScreen?: AppScreen) => {
    if (loadingScreen) {
      setScreen(loadingScreen);
      setTimeout(() => setScreen(target), 1800);
    } else {
      setScreen(target);
    }
  }, []);

  const handleNavigate = useCallback((page: string) => {
    if (page.startsWith('card-details:')) {
      setSelectedAccountId(page.split(':')[1]);
      transitionTo('card-details');
      return;
    }
    const loadingTargets: Record<string, AppScreen> = {
      'dashboard': 'dashboard',
      'transfer': 'transfer',
      'profile': 'profile',
      'card-details': 'card-details',
      'analytics': 'analytics',
      'support': 'support',
      'notifications': 'notifications',
      'settings': 'settings',
      'account-details': 'account-details',
      'manage-cards': 'manage-cards',
      'security-center': 'security-center',
      'notification-settings': 'notification-settings',
      'statements': 'statements',
      'wire-transfers': 'wire-transfers',
      'mobile-settings': 'mobile-settings',
      'privacy': 'privacy',
      'help-support': 'help-support',
      'transaction-history': 'transaction-history',
    };
    const target = loadingTargets[page];
    if (target) transitionTo(target);
  }, [transitionTo]);

  const handleLogout = useCallback(() => {
    setScreen('splash');
  }, []);

  return (
    <BankingProvider>
      <div className="max-w-lg mx-auto min-h-screen relative bg-background">
        {screen === 'splash' && <SplashScreen onComplete={() => transitionTo('login')} />}
        {screen === 'login' && <LoginPage onLogin={() => transitionTo('otp', 'login-loading')} />}
        {screen === 'login-loading' && <CircleLoader message="Signing in..." />}
        {screen === 'otp' && <OTPVerification onVerify={() => transitionTo('dashboard', 'otp-loading')} />}
        {screen === 'otp-loading' && <CircleLoader message="Verifying..." />}
        {screen === 'dashboard' && <Dashboard onNavigate={handleNavigate} />}
        {screen === 'transfer' && <TransferPage onNavigate={handleNavigate} />}
        {screen === 'profile' && <ProfilePage onNavigate={handleNavigate} onLogout={handleLogout} />}
        {screen === 'card-details' && <CardDetailsPage onNavigate={handleNavigate} accountId={selectedAccountId} />}
        {screen === 'analytics' && <AnalyticsPage onNavigate={handleNavigate} />}
        {screen === 'support' && <SupportPage onNavigate={handleNavigate} />}
        {screen === 'notifications' && <NotificationsPage onNavigate={handleNavigate} />}
        {screen === 'account-details' && <AccountDetailsPage onNavigate={handleNavigate} />}
        {screen === 'manage-cards' && <ManageCardsPage onNavigate={handleNavigate} />}
        {screen === 'security-center' && <SecurityCenterPage onNavigate={handleNavigate} />}
        {screen === 'notification-settings' && <NotificationSettingsPage onNavigate={handleNavigate} />}
        {screen === 'statements' && <StatementsPage onNavigate={handleNavigate} />}
        {screen === 'wire-transfers' && <WireTransfersPage onNavigate={handleNavigate} />}
        {screen === 'mobile-settings' && <MobileSettingsPage onNavigate={handleNavigate} />}
        {screen === 'privacy' && <PrivacyPage onNavigate={handleNavigate} />}
        {screen === 'help-support' && <HelpSupportPage onNavigate={handleNavigate} />}
        {screen === 'transaction-history' && <TransactionHistoryPage onNavigate={handleNavigate} />}
      </div>
    </BankingProvider>
  );
};

const SupportPage = ({ onNavigate }: { onNavigate: (p: string) => void }) => (
  <div className="min-h-screen bg-background">
    <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4">
      <button onClick={() => onNavigate('dashboard')} aria-label="Go back to dashboard"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button>
      <h1 className="text-xl font-bold text-foreground">Help & Support</h1>
    </div>
    <div className="px-5 mt-4 space-y-3">
      {['Call Support (1-800-869-3557)', 'Chat with Us', 'Find a Branch', 'Report Fraud', 'FAQ'].map((item, i) => (
        <div key={i} className="bg-card rounded-xl p-4 shadow-sm text-sm font-medium text-foreground">{item}</div>
      ))}
    </div>
  </div>
);

const NotificationsPage = ({ onNavigate }: { onNavigate: (p: string) => void }) => (
  <div className="min-h-screen bg-background">
    <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4">
      <button onClick={() => onNavigate('dashboard')} aria-label="Go back to dashboard"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button>
      <h1 className="text-xl font-bold text-foreground">Notifications</h1>
    </div>
    <div className="px-5 mt-4 space-y-3">
      {[
        { title: 'Security Alert', desc: 'New sign-in from your device', time: 'Just now' },
        { title: 'Payment Received', desc: 'Casey Newman sent you $50.00', time: '2h ago' },
        { title: 'Bill Due', desc: 'Your credit card payment is due in 5 days', time: '1d ago' },
      ].map((n, i) => (
        <div key={i} className="bg-card rounded-xl p-4 shadow-sm">
          <div className="flex justify-between"><p className="text-sm font-semibold text-foreground">{n.title}</p><span className="text-xs text-muted-foreground">{n.time}</span></div>
          <p className="text-xs text-muted-foreground mt-1">{n.desc}</p>
        </div>
      ))}
    </div>
  </div>
);

export default Index;
