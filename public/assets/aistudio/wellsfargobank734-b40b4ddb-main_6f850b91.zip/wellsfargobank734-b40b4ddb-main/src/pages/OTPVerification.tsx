import { useState, useEffect, useRef } from 'react';

const OTPVerification = ({ onVerify }: { onVerify: () => void }) => {
  const [step, setStep] = useState<'animate' | 'input'>('animate');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [error, setError] = useState('');
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => setStep('input'), 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 3) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = () => {
    const code = otp.join('');
    if (code === '5321') { setError(''); onVerify(); }
    else { setError('Invalid code. Please try again.'); setOtp(['', '', '', '']); inputRefs.current[0]?.focus(); }
  };

  if (step === 'animate') {
    return (
      <div className="fixed inset-0 bg-card flex flex-col items-center justify-center">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" strokeWidth="2"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/></svg>
          </div>
          <div className="absolute inset-0 w-24 h-24 rounded-full border-2 border-primary/40 animate-pulse-ring" />
          <div className="absolute inset-0 w-24 h-24 rounded-full border-2 border-primary/20 animate-pulse-ring" style={{ animationDelay: '0.5s' }} />
        </div>
        <h1 className="mt-6 text-lg font-semibold text-foreground animate-fade-up">Sending verification code...</h1>
        <p className="mt-2 text-sm text-muted-foreground animate-fade-up" style={{ animationDelay: '0.3s' }}>To your registered phone number</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-card flex flex-col items-center justify-center px-6">
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" strokeWidth="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
      </div>
      <h1 className="text-2xl font-bold text-foreground mb-2">Verify Your Identity</h1>
      <p className="text-sm text-muted-foreground text-center mb-8">Enter the 4-digit code sent to your phone number ending in ***42</p>

      <div className="flex gap-4 mb-6">
        {otp.map((digit, i) => (
          <input
            key={i}
            ref={el => { inputRefs.current[i] = el; }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={digit}
            onChange={e => handleChange(i, e.target.value)}
            onKeyDown={e => handleKeyDown(i, e)}
            className="w-14 h-14 text-center text-2xl font-bold border-2 border-border rounded-lg bg-card text-foreground focus:border-primary focus:outline-none transition-colors"
          />
        ))}
      </div>

      {error && <p className="text-destructive text-sm mb-4">{error}</p>}

      <button onClick={handleSubmit} className="w-full max-w-xs py-3 bg-primary text-primary-foreground font-semibold rounded-lg text-lg hover:opacity-90 transition-opacity">
        Verify
      </button>
      <p className="mt-4 text-sm text-muted-foreground">Didn't receive the code? <span className="text-primary font-semibold cursor-pointer">Resend</span></p>
    </div>
  );
};

export default OTPVerification;
