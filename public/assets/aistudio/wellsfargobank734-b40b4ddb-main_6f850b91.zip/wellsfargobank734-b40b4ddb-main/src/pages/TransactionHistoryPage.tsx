import { useMemo, useState } from 'react';
import { useBanking } from '@/contexts/BankingContext';
import { ArrowLeft, Search, SlidersHorizontal } from 'lucide-react';

const PAGE_SIZE = 40;

const TransactionHistoryPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const { transactions, accounts } = useBanking();
  const [query, setQuery] = useState('');
  const [accountId, setAccountId] = useState('all');
  const [type, setType] = useState<'all' | 'debit' | 'credit'>('all');
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(
    () =>
      transactions.filter(t => {
        if (accountId !== 'all' && t.accountId !== accountId) return false;
        if (type !== 'all' && t.type !== type) return false;
        if (query && !`${t.name} ${t.category}`.toLowerCase().includes(query.toLowerCase())) return false;
        return true;
      }),
    [transactions, accountId, type, query],
  );

  const totals = useMemo(
    () => ({
      out: filtered.filter(t => t.type === 'debit').reduce((s, t) => s + t.amount, 0),
      in: filtered.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0),
    }),
    [filtered],
  );

  const groups = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    filtered.slice(0, visible).forEach(t => {
      const key = new Date(t.timestamp).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(t);
    });
    return [...map.entries()];
  }, [filtered, visible]);

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="bg-card px-5 pt-6 pb-4 sticky top-0 z-30 border-b border-border">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} aria-label="Go back"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground">Transaction History</h1>
            <p className="text-xs text-muted-foreground">{filtered.length.toLocaleString()} transactions</p>
          </div>
          <button onClick={() => setShowFilters(!showFilters)} aria-label="Filters"><SlidersHorizontal className="w-5 h-5 text-primary" /></button>
        </div>

        <div className="mt-3 flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
          <Search className="w-4 h-4 text-muted-foreground" />
          <input
            value={query}
            onChange={e => { setQuery(e.target.value); setVisible(PAGE_SIZE); }}
            placeholder="Search merchant or category"
            className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
        </div>

        {showFilters && (
          <div className="mt-3 space-y-2">
            <div className="flex gap-2 overflow-x-auto pb-1">
              {[{ id: 'all', name: 'All accounts' }, ...accounts].map(a => (
                <button
                  key={a.id}
                  onClick={() => { setAccountId(a.id); setVisible(PAGE_SIZE); }}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${accountId === a.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                >
                  {a.name}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              {(['all', 'debit', 'credit'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => { setType(t); setVisible(PAGE_SIZE); }}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold capitalize ${type === t ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                >
                  {t === 'all' ? 'All types' : t === 'debit' ? 'Money out' : 'Money in'}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="px-5 mt-4 grid grid-cols-2 gap-3">
        <div className="bg-card rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Money out</p>
          <p className="text-base font-bold text-destructive">${totals.out.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground">Money in</p>
          <p className="text-base font-bold text-green-600">${totals.in.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
      </div>

      <div className="px-5 mt-4 space-y-4">
        {groups.map(([day, items]) => (
          <div key={day}>
            <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">{day}</p>
            <div className="bg-card rounded-xl shadow-sm divide-y divide-border overflow-hidden">
              {items.map(tx => (
                <div key={tx.id} className="flex items-center gap-3 p-4">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground">
                    {tx.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{tx.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {tx.category} · {new Date(tx.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                      {tx.status === 'pending' && ' · Pending'}
                    </p>
                  </div>
                  <p className={`text-sm font-bold ${tx.type === 'debit' ? 'text-foreground' : 'text-green-600'}`}>
                    {tx.type === 'debit' ? '-' : '+'}${tx.amount.toFixed(2)}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ))}

        {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-10">No transactions match your filters.</p>}

        {visible < filtered.length && (
          <button onClick={() => setVisible(v => v + PAGE_SIZE)} className="w-full bg-card rounded-xl py-3 text-sm font-semibold text-primary shadow-sm">
            Load more ({(filtered.length - visible).toLocaleString()} remaining)
          </button>
        )}
      </div>
    </div>
  );
};

export default TransactionHistoryPage;
