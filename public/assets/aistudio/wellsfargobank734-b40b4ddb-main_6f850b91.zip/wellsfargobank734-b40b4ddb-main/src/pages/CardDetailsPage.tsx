import { useBanking } from '@/contexts/BankingContext';
import chipImg from '@/assets/chip.png';
import visaLogo from '@/assets/visa-logo.svg';
import { ArrowLeft, CreditCard, FileText, MoreHorizontal } from 'lucide-react';
import { useState } from 'react';

const CardDetailsPage = ({ onNavigate, accountId }: { onNavigate: (page: string) => void; accountId?: string }) => {
  const { accounts, transactions, userName } = useBanking();
  const credit = accounts.find(a => a.id === accountId) ?? accounts[2];
  const [tab, setTab] = useState('transactions');

  return (
    <div className="min-h-screen bg-background pb-8">
      <div className="bg-card px-5 pt-6 pb-4 flex items-center justify-between">
        <button onClick={() => onNavigate('dashboard')} aria-label="Go back to dashboard"><ArrowLeft className="w-6 h-6 text-foreground" /></button>
        <h1 className="text-lg font-bold text-foreground">Card Details</h1>
        <MoreHorizontal className="w-6 h-6 text-foreground" />
      </div>

      <div className="px-5 mt-4">
        <div className="card-gradient rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <p className="text-primary-foreground text-sm font-medium">{credit.name}</p>
            <img src={visaLogo} alt="Visa" className="h-5 brightness-0 invert" />
          </div>
          <img src={chipImg} alt="Chip" className="w-10 h-8 object-contain mb-3" />
          <div className="text-center mb-2">
            <p className="text-primary-foreground/60 text-xs">{credit.type === 'credit' ? 'Outstanding balance' : 'Available balance'}</p>
            <p className="text-primary-foreground text-3xl font-bold">${credit.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
            <p className="text-primary-foreground/60 text-xs mt-1">...{credit.lastFour}</p>
          </div>
        </div>
      </div>

      <div className="px-5 mt-4 flex gap-3">
        {[
          { label: 'Payment', desc: 'Make payment', icon: <CreditCard className="w-5 h-5" /> },
          { label: 'Card Info', desc: 'View details', icon: <FileText className="w-5 h-5" /> },
        ].map((btn, i) => (
          <button key={i} className="flex-1 bg-card rounded-xl p-3 flex flex-col items-center gap-1 shadow-sm">
            <div className="text-primary">{btn.icon}</div>
            <p className="text-xs font-semibold text-foreground">{btn.label}</p>
            <p className="text-[10px] text-muted-foreground">{btn.desc}</p>
          </button>
        ))}
      </div>

      <div className="px-5 mt-4">
        <div className="flex border-b border-border">
          {['transactions', 'payments', 'charges'].map(t => (
            <button key={t} onClick={() => setTab(t)} className={`flex-1 py-2 text-sm font-medium transition-colors ${tab === t ? 'text-foreground border-b-2 border-primary' : 'text-muted-foreground'}`}>
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 mt-3 space-y-3">
        {transactions
          .filter(tx => tx.accountId === credit.id)
          .filter(tx => (tab === 'payments' ? tx.type === 'credit' : tab === 'charges' ? tx.type === 'debit' : true))
          .slice(0, 25)
          .map(tx => (
            <div key={tx.id} className="bg-card rounded-xl p-4 flex items-center gap-3 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground">{tx.name.charAt(0)}</div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{tx.name}</p>
                <p className="text-xs text-muted-foreground">{tx.date}</p>
              </div>
              <p className={`text-sm font-bold ${tx.type === 'debit' ? 'text-foreground' : 'text-green-600'}`}>
                {tx.type === 'debit' ? '-' : '+'}${tx.amount.toFixed(2)}
              </p>
            </div>
          ))}
        <button onClick={() => onNavigate('transaction-history')} className="w-full bg-card rounded-xl py-3 text-sm font-semibold text-primary shadow-sm">
          View all transactions
        </button>
      </div>
    </div>
  );
};

export default CardDetailsPage;
