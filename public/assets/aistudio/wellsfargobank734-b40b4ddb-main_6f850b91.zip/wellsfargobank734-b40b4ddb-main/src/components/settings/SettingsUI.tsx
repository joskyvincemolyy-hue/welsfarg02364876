import { ArrowLeft } from 'lucide-react';
import { ReactNode } from 'react';

export const PageShell = ({
  title,
  onBack,
  children,
  subtitle,
}: {
  title: string;
  subtitle?: string;
  onBack: () => void;
  children: ReactNode;
}) => (
  <div className="min-h-screen bg-background pb-10">
    <div className="bg-card px-5 pt-6 pb-4 flex items-center gap-4 sticky top-0 z-30 border-b border-border">
      <button onClick={onBack} aria-label="Go back">
        <ArrowLeft className="w-6 h-6 text-foreground" />
      </button>
      <div>
        <h1 className="text-xl font-bold text-foreground">{title}</h1>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>
    </div>
    <div className="px-5 mt-4 space-y-4">{children}</div>
  </div>
);

export const Section = ({ title, children }: { title?: string; children: ReactNode }) => (
  <div>
    {title && <h2 className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">{title}</h2>}
    <div className="bg-card rounded-xl shadow-sm divide-y divide-border overflow-hidden">{children}</div>
  </div>
);

export const ToggleRow = ({
  label,
  desc,
  checked,
  onChange,
}: {
  label: string;
  desc?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) => (
  <div className="flex items-center gap-3 p-4">
    <div className="flex-1">
      <p className="text-sm font-semibold text-foreground">{label}</p>
      {desc && <p className="text-xs text-muted-foreground">{desc}</p>}
    </div>
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`w-12 h-7 rounded-full transition-colors flex-shrink-0 ${checked ? 'bg-primary' : 'bg-muted'}`}
    >
      <span
        className={`block w-5 h-5 rounded-full bg-card shadow transition-transform mt-1 ${
          checked ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </button>
  </div>
);

export const SelectRow = ({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) => (
  <div className="flex items-center gap-3 p-4">
    <p className="flex-1 text-sm font-semibold text-foreground">{label}</p>
    <select
      aria-label={label}
      value={value}
      onChange={e => onChange(e.target.value)}
      className="bg-muted text-foreground text-sm rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary"
    >
      {options.map(o => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  </div>
);

export const InputRow = ({
  label,
  value,
  onChange,
  type = 'text',
  prefix,
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
  prefix?: string;
}) => (
  <div className="p-4">
    <label className="block text-xs text-muted-foreground mb-1">{label}</label>
    <div className="flex items-center gap-1">
      {prefix && <span className="text-sm text-muted-foreground">{prefix}</span>}
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full bg-transparent text-sm font-semibold text-foreground border-b border-border focus:border-primary focus:outline-none py-1"
      />
    </div>
  </div>
);

export const SavedToast = ({ show }: { show: boolean }) => (
  <div
    className={`fixed bottom-6 left-1/2 -translate-x-1/2 bg-foreground text-background text-sm font-medium px-4 py-2 rounded-full shadow-lg transition-opacity z-50 ${
      show ? 'opacity-100' : 'opacity-0 pointer-events-none'
    }`}
  >
    Changes saved
  </div>
);
