import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';

export interface Transaction {
  id: string;
  name: string;
  date: string;
  timestamp: number;
  amount: number;
  type: 'debit' | 'credit';
  icon?: string;
  category: string;
  accountId: string;
  status: 'completed' | 'pending';
}

export interface Account {
  id: string;
  name: string;
  type: string;
  lastFour: string;
  balance: number;
}

export interface CardInfo {
  id: string;
  accountId: string;
  name: string;
  lastFour: string;
  brand: string;
  expires: string;
  frozen: boolean;
  contactless: boolean;
  onlinePayments: boolean;
  internationalUse: boolean;
  spendLimit: number;
}

export interface Settings {
  // security
  biometrics: boolean;
  twoFactor: boolean;
  loginAlerts: boolean;
  // notifications
  pushNotifications: boolean;
  emailAlerts: boolean;
  smsAlerts: boolean;
  marketingEmails: boolean;
  lowBalanceAlerts: boolean;
  lowBalanceThreshold: number;
  // wire transfers
  internationalWires: boolean;
  wireCurrency: string;
  wireDailyLimit: number;
  swiftCode: string;
  // mobile
  darkMode: boolean;
  language: string;
  hideBalances: boolean;
  quickBalance: boolean;
  // privacy
  shareDataPartners: boolean;
  personalizedOffers: boolean;
  locationTracking: boolean;
  analyticsOptIn: boolean;
}

export interface Profile {
  userName: string;
  email: string;
  phone: string;
  address: string;
  dateOfBirth: string;
  occupation: string;
}

const DEFAULT_SETTINGS: Settings = {
  biometrics: true,
  twoFactor: true,
  loginAlerts: true,
  pushNotifications: true,
  emailAlerts: true,
  smsAlerts: false,
  marketingEmails: false,
  lowBalanceAlerts: true,
  lowBalanceThreshold: 100,
  internationalWires: false,
  wireCurrency: 'USD',
  wireDailyLimit: 25000,
  swiftCode: 'WFBIUS6S',
  darkMode: false,
  language: 'English',
  hideBalances: false,
  quickBalance: true,
  shareDataPartners: false,
  personalizedOffers: true,
  locationTracking: false,
  analyticsOptIn: true,
};

const DEFAULT_PROFILE: Profile = {
  userName: 'Jackson Browne',
  email: 'jackson.browne@email.com',
  phone: '+1 (415) 555-0142',
  address: '2140 Sunset Blvd, San Francisco, CA 94110',
  dateOfBirth: 'October 23, 1976',
  occupation: 'Private Investor',
};

/* ---------- transaction generation (1000 records) ---------- */
const MERCHANTS: { name: string; category: string; type: 'debit' | 'credit'; min: number; max: number }[] = [
  { name: 'UberX', category: 'Transport', type: 'debit', min: 8, max: 62 },
  { name: 'Lyft', category: 'Transport', type: 'debit', min: 7, max: 55 },
  { name: 'Shell Gas Station', category: 'Transport', type: 'debit', min: 25, max: 95 },
  { name: "McDonald's", category: 'Food', type: 'debit', min: 4, max: 28 },
  { name: 'Starbucks', category: 'Food', type: 'debit', min: 3, max: 19 },
  { name: 'Whole Foods Market', category: 'Groceries', type: 'debit', min: 22, max: 240 },
  { name: 'Trader Joes', category: 'Groceries', type: 'debit', min: 18, max: 160 },
  { name: 'Netflix', category: 'Entertainment', type: 'debit', min: 15.99, max: 15.99 },
  { name: 'Spotify', category: 'Entertainment', type: 'debit', min: 11.99, max: 11.99 },
  { name: 'Amazon', category: 'Shopping', type: 'debit', min: 9, max: 480 },
  { name: 'Apple Store', category: 'Shopping', type: 'debit', min: 29, max: 1299 },
  { name: 'Target', category: 'Shopping', type: 'debit', min: 12, max: 320 },
  { name: 'Delta Airlines', category: 'Travel', type: 'debit', min: 180, max: 1450 },
  { name: 'Marriott Hotels', category: 'Travel', type: 'debit', min: 145, max: 890 },
  { name: 'PG&E Utility', category: 'Bills', type: 'debit', min: 60, max: 310 },
  { name: 'AT&T Wireless', category: 'Bills', type: 'debit', min: 45, max: 190 },
  { name: 'Blue Cross Insurance', category: 'Bills', type: 'debit', min: 210, max: 520 },
  { name: 'ATM Withdrawal', category: 'Cash withdrawal', type: 'debit', min: 40, max: 800 },
  { name: 'Emily Gordon', category: 'Transfer', type: 'debit', min: 20, max: 900 },
  { name: 'Marcus Reed', category: 'Transfer', type: 'debit', min: 25, max: 1200 },
  { name: 'Casey Newman', category: 'Transfer', type: 'credit', min: 30, max: 1500 },
  { name: 'Salary Deposit', category: 'Income', type: 'credit', min: 4200, max: 6800 },
  { name: 'Dividend Payout', category: 'Income', type: 'credit', min: 120, max: 4300 },
  { name: 'Refund - Amazon', category: 'Income', type: 'credit', min: 12, max: 310 },
  { name: 'Interest Payment', category: 'Income', type: 'credit', min: 2, max: 95 },
];

const ACCOUNT_IDS = ['1', '1', '1', '2', '3', '3'];

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function formatDate(ts: number) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const time = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (sameDay) return `Today, ${time}`;
  const yest = new Date(now.getTime() - 86400000);
  if (d.toDateString() === yest.toDateString()) return `Yesterday, ${time}`;
  return `${d.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' })}, ${time}`;
}

function generateTransactions(count: number): Transaction[] {
  const rand = mulberry32(20260813);
  const now = Date.now();
  const list: Transaction[] = [];
  for (let i = 0; i < count; i++) {
    const m = MERCHANTS[Math.floor(rand() * MERCHANTS.length)];
    const amount = Math.round((m.min + rand() * (m.max - m.min)) * 100) / 100;
    // spread over ~3 years, newest first
    const ts = now - Math.floor(i * (1000 * 60 * 60 * 26) + rand() * 1000 * 60 * 60 * 20);
    list.push({
      id: `tx-${i + 1}`,
      name: m.name,
      category: m.category,
      type: m.type,
      amount,
      timestamp: ts,
      date: formatDate(ts),
      accountId: ACCOUNT_IDS[Math.floor(rand() * ACCOUNT_IDS.length)],
      status: i < 3 && rand() > 0.6 ? 'pending' : 'completed',
    });
  }
  return list;
}

interface BankingContextType {
  accounts: Account[];
  transactions: Transaction[];
  cards: CardInfo[];
  settings: Settings;
  profile: Profile;
  userName: string;
  accountNumber: string;
  routingNumber: string;
  addTransaction: (tx: Omit<Transaction, 'id' | 'timestamp' | 'status'> & { timestamp?: number }) => void;
  debitAccount: (accountId: string, amount: number) => void;
  updateSetting: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  updateProfile: (patch: Partial<Profile>) => void;
  updateCard: (cardId: string, patch: Partial<CardInfo>) => void;
}

const BankingContext = createContext<BankingContextType | undefined>(undefined);

export const useBanking = () => {
  const ctx = useContext(BankingContext);
  if (!ctx) throw new Error('useBanking must be used within BankingProvider');
  return ctx;
};

const load = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
};

export const BankingProvider = ({ children }: { children: ReactNode }) => {
  const [accounts, setAccounts] = useState<Account[]>([
    { id: '1', name: 'Everyday Checking', type: 'checking', lastFour: '8102', balance: 1300345106.72 },
    { id: '2', name: 'Way2Save Savings', type: 'savings', lastFour: '0125', balance: 8100.0 },
    { id: '3', name: 'Visa Signature', type: 'credit', lastFour: '1402', balance: 335.85 },
  ]);

  const generated = useMemo(() => generateTransactions(1000), []);
  const [transactions, setTransactions] = useState<Transaction[]>(generated);

  const [cards, setCards] = useState<CardInfo[]>(() =>
    load<CardInfo[]>('wf_cards', [
      { id: 'c1', accountId: '3', name: 'Visa Signature', lastFour: '1402', brand: 'Visa', expires: '09/28', frozen: false, contactless: true, onlinePayments: true, internationalUse: false, spendLimit: 10000 },
      { id: 'c2', accountId: '1', name: 'Everyday Checking Debit', lastFour: '8102', brand: 'Debit', expires: '04/29', frozen: false, contactless: true, onlinePayments: true, internationalUse: false, spendLimit: 5000 },
      { id: 'c3', accountId: '2', name: 'Way2Save ATM Card', lastFour: '0125', brand: 'ATM', expires: '11/27', frozen: true, contactless: false, onlinePayments: false, internationalUse: false, spendLimit: 1000 },
    ]),
  );

  const [settings, setSettings] = useState<Settings>(() => load('wf_settings', DEFAULT_SETTINGS));
  const [profile, setProfile] = useState<Profile>(() => load('wf_profile_v2', DEFAULT_PROFILE));

  useEffect(() => { localStorage.setItem('wf_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('wf_profile_v2', JSON.stringify(profile)); }, [profile]);
  useEffect(() => { localStorage.setItem('wf_cards', JSON.stringify(cards)); }, [cards]);
  useEffect(() => {
    document.documentElement.classList.toggle('dark', settings.darkMode);
  }, [settings.darkMode]);

  const addTransaction: BankingContextType['addTransaction'] = (tx) => {
    const ts = tx.timestamp ?? Date.now();
    setTransactions(prev => [{ ...tx, id: `tx-${Date.now()}`, timestamp: ts, status: 'completed' }, ...prev]);
  };

  const debitAccount = (accountId: string, amount: number) => {
    setAccounts(prev => prev.map(a => (a.id === accountId ? { ...a, balance: a.balance - amount } : a)));
  };

  const updateSetting: BankingContextType['updateSetting'] = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const updateProfile = (patch: Partial<Profile>) => setProfile(prev => ({ ...prev, ...patch }));

  const updateCard = (cardId: string, patch: Partial<CardInfo>) =>
    setCards(prev => prev.map(c => (c.id === cardId ? { ...c, ...patch } : c)));

  return (
    <BankingContext.Provider
      value={{
        accounts,
        transactions,
        cards,
        settings,
        profile,
        userName: profile.userName,
        accountNumber: '4821-7390-5562',
        routingNumber: '121000248',
        addTransaction,
        debitAccount,
        updateSetting,
        updateProfile,
        updateCard,
      }}
    >
      {children}
    </BankingContext.Provider>
  );
};
